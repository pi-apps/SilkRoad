# jPopup
##### Advanced jQuery plugin to show popups.
#### [Demo](http://jpopup.seapip.com/)&nbsp;&nbsp;&nbsp;&nbsp;[Documentation](http://jpopup.seapip.com/)
<br>
###Features
- Supports all browsers including IE6 and above.
- Small footprint with a filesize of just 3KB.
- No CSS dependencies.
- Responsive.
